JoeChalhoub_FxCrusher 

This indicator is presented to public I hope all traders find it profitable.
Setup:

1 - Downlaod Metatrader 4 [www.metaquotes.net/downloads]

3 - Go to http://rpchost.com/IssueIndicator.aspx web page
and enter your UserID and Password and press login. In case you are not registered Go to 
http://rpchost.com/RegisterContent.aspx and register.

5 - After you login press the "Download JoeChalhoub_FxCrusher Indicator" button.


2 - After metatrader installation Copy/Paste JoeChalhoub_FxCrusher.ex4 in
C:\Program Files\MetaTrader 4\experts\indicators folder

3 - Copy/Paste the InputBox.dll file in C:\Program Files\MetaTrader 4\experts\libraries folder



6 - The life cycle opf the indicator is 3 days each time it expired relogin and press the 
"Renew JoeChalhoub_FxCrusher Indicator for another 3 days" button.




